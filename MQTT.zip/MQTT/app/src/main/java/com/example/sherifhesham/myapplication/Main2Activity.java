package com.example.sherifhesham.myapplication;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Vibrator;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.net.URL;

public class Main2Activity extends AppCompatActivity {

    String Topic;
    String Message;
    TextView Subs;
    TextView msg;
    TextView Connection;
    TextView Receivingmsg;
    Switch hello;
    Switch bye;
    String msg1;
    Vibrator vibrator;
    Ringtone ringtone;
    String Arrived;
    MqttAndroidClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Arrived = "";
        msg1 = "Hello";

        Subs = (TextView) findViewById(R.id.editText5);
        msg = (TextView) findViewById(R.id.editText6);
        Connection = (TextView) findViewById(R.id.textView6);
        Receivingmsg = (TextView) findViewById(R.id.textView7);
        hello = (Switch) findViewById(R.id.switch1);
        bye = (Switch) findViewById(R.id.switch2);
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);

        Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        ringtone = RingtoneManager.getRingtone(getApplicationContext(),uri);

        Receivingmsg.setMovementMethod(new ScrollingMovementMethod());


            Bundle extras = getIntent().getExtras();
            String URL = extras.getString("Key1");
            String clientid = extras.getString("Key2");
            String User = extras.getString("Key3");
            String Pass = extras.getString("Key4");
            client = new MqttAndroidClient(this.getApplicationContext(), URL, clientid);
            MqttConnectOptions options = new MqttConnectOptions();
            options.setUserName(User);
            options.setPassword(Pass.toCharArray());

        try {
            IMqttToken token = client.connect(options);
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Toast.makeText(Main2Activity.this, "Connected", Toast.LENGTH_SHORT).show();
                    Connection.setText("Connected");

                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Toast.makeText(Main2Activity.this, "Connection Failed", Toast.LENGTH_SHORT).show();
                    final Intent intent = new Intent(Main2Activity.this, MainActivity.class);
                    startActivity(intent);
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }

        client.setCallback(new MqttCallback() {
            @Override
            public void connectionLost(Throwable cause) {
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception
            {

                NotificationCompat.Builder notificationbuilder = new NotificationCompat.Builder(Main2Activity.this)
                        .setSmallIcon(android.R.drawable.stat_notify_error)
                        .setLargeIcon(BitmapFactory.decodeResource(getResources(),R.mipmap.ic_launcher))
                        .setContentTitle("MQTT")
                        .setContentText("New message has arrived");
                notificationbuilder.setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_LIGHTS | Notification.DEFAULT_VIBRATE);
                NotificationManagerCompat notificationManagerCompat =  NotificationManagerCompat.from(Main2Activity.this);
                notificationManagerCompat.notify(1,notificationbuilder.build());


                String Mqttmsg = new String(message.getPayload());
                Arrived = Arrived + " Received Topic: "+ topic + "\n" + " Message: " + Mqttmsg + "\n" + "\n";
                Receivingmsg.setText(Arrived);
                vibrator.vibrate(500);
                ringtone.play();

            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
            }
        });

        hello.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(isChecked && Topic != null)
                {
                    String message = "Hello";
                    try
                    {
                        client.publish(Topic, message.getBytes(), 0, false);
                        Toast.makeText(Main2Activity.this, "Sent", Toast.LENGTH_SHORT).show();
                    }
                    catch (MqttException e)
                    {
                        e.printStackTrace();
                    }
                }
                else if(isChecked && Topic == null)
                {
                    Toast.makeText(Main2Activity.this, "Please enter a topic", Toast.LENGTH_SHORT).show();
                }
            }

        });

        bye.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(isChecked && Topic != null)
                {
                    String message = "Bye";
                    try
                    {
                        client.publish(Topic, message.getBytes(), 0, false);
                        Toast.makeText(Main2Activity.this, "Sent", Toast.LENGTH_SHORT).show();
                    }
                    catch (MqttException e)
                    {
                        e.printStackTrace();
                    }
                }
                else if(isChecked && Topic == null)
                {
                    Toast.makeText(Main2Activity.this, "Please enter a topic", Toast.LENGTH_SHORT).show();
                }
            }

        });
    }



    public void Subscribe(View v)
    {
        Topic = Subs.getText().toString();
        if (Topic.length()==0)
            Toast.makeText(Main2Activity.this, "Please enter a topic", Toast.LENGTH_SHORT).show();
        else{
            try{
                client.subscribe(Topic,0);
                Toast.makeText(Main2Activity.this, "Subscribed", Toast.LENGTH_SHORT).show();
            }
            catch(MqttException e)
            {
                e.printStackTrace();
            }
        }
    }

    public void Publish(View v)
    {
        Message = msg.getText().toString();
        if(Topic.length()==0 || Message.length()==0) {
            Toast.makeText(Main2Activity.this, "Please enter a topic and press subscribe and the message", Toast.LENGTH_SHORT).show();
        }
        else
        {
            try
            {
                client.publish(Topic, Message.getBytes(), 0, false);
                Toast.makeText(Main2Activity.this, "Sent", Toast.LENGTH_SHORT).show();
            }
            catch (MqttException e)
            {
                e.printStackTrace();
            }
        }
    }

    public void Disconnect (View v)
    {
        try{
            IMqttToken token = client.disconnect();
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Toast.makeText(Main2Activity.this, "Disconnected", Toast.LENGTH_SHORT).show();
                    Connection.setText("Disconnected");
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Toast.makeText(Main2Activity.this, "Can not disconnect", Toast.LENGTH_SHORT).show();
                }
            });
        }
        catch (MqttException e)
        {
            e.printStackTrace();
        }
    }
}
