package com.example.sherifhesham.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.MqttClient;

public class MainActivity extends AppCompatActivity {

    String SERVER;
    String USER ;
    String PASSWORD;
    String PORT;
    String URL;
    TextView ServerText;
    TextView UserText;
    TextView PasswordText;
    TextView PortNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ServerText = (TextView) findViewById(R.id.editText);
        UserText = (TextView) findViewById(R.id.editText2);
        PasswordText = (TextView) findViewById(R.id.editText3);
        PortNumber = (TextView) findViewById(R.id.editText4);

    }

    public void Connect(View v) {

        SERVER = ServerText.getText().toString();
        USER = UserText.getText().toString();
        PASSWORD = PasswordText.getText().toString();
        PORT = PortNumber.getText().toString();
        final String clientId = MqttClient.generateClientId();
        URL = "tcp://" + SERVER + ":" + PORT;

        if (SERVER.length() == 0 || USER.length() == 0 || PASSWORD.length() == 0)
            Toast.makeText(MainActivity.this, "Failed To Connect Please Fill All The Requirements", Toast.LENGTH_SHORT).show();

        else
            {
            Toast.makeText(MainActivity.this, "connecting", Toast.LENGTH_SHORT).show();
            final Intent intent = new Intent(MainActivity.this, Main2Activity.class);
            intent.putExtra("Key1", URL);
            intent.putExtra("Key2", clientId);
            intent.putExtra("Key3", USER);
            intent.putExtra("Key4", PASSWORD);
            intent.putExtra("key5", SERVER);
            startActivity(intent);
        }
    }
}
